
const express = require('express');
const bodyParser = require('body-parser');
const pool = require('./db');
const path = require('path');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

app.get('/productos', async (req, res) => {
  const result = await pool.query('SELECT * FROM producto ORDER BY id_producto');
  res.json(result.rows);
});

app.post('/agregar-producto', async (req, res) => {
  const { nombre, descripcion, unidad_medida, stock_minimo, stock_actual, precio_unitario, categoria_id, proveedor_id } = req.body;
  await pool.query(
    'INSERT INTO producto (nombre, descripcion, unidad_medida, stock_minimo, stock_actual, precio_unitario, categoria_id, proveedor_id) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',
    [nombre, descripcion, unidad_medida, stock_minimo, stock_actual, precio_unitario, categoria_id, proveedor_id]
  );
  res.redirect('/');
});

app.post('/login', async (req, res) => {
  const { nombre, password } = req.body;
  try {
    const result = await pool.query(
      'SELECT * FROM usuario WHERE nombre = $1 AND contraseña = $2',
      [nombre, password]
    );
    if (result.rows.length > 0) {
      res.send('<script>alert("Bienvenido"); window.location.href = "/";</script>');
    } else {
      res.send('<script>alert("Credenciales incorrectas"); window.location.href = "/login.html";</script>');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Error interno del servidor');
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
